# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree.

from torchtitan.distributed.pipeline_parallel import pipeline_llm
from torchtitan.experiments.ft.config.job_config import FaultTolerantModelSpec
from torchtitan.experiments.ft.diloco import fragment_llm
from torchtitan.models.llama3 import (
    llama3_configs,
    Llama3StateDictAdapter,
    parallelize_llama,
)


def model_registry(flavor: str, attn_backend: str = "sdpa") -> FaultTolerantModelSpec:
    config = llama3_configs[flavor](attn_backend=attn_backend)
    return FaultTolerantModelSpec(
        name="ft/llama3",
        flavor=flavor,
        model=config,
        parallelize_fn=parallelize_llama,
        pipelining_fn=pipeline_llm,
        post_optimizer_build_fn=None,
        state_dict_adapter=Llama3StateDictAdapter,
        fragment_fn=fragment_llm,
    )
